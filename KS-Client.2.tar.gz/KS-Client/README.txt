To install:
Install nodejs. http://nodejs.org
Edit start.js with notepad, adding your username and password. This is required because of how the client works, as a proxy.
Double click start.bat (Or if you're on linux I assume you know how to run 'node start.js')